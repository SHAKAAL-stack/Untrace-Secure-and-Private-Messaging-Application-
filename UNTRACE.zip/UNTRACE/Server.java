import java.io.*;
import java.net.*;

public class Server {
    private static final String PASSWORD = "in both ca i have 0 marks"; // Change to your desired password

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(1234);
            System.out.println("Server started. Waiting for a client...");

            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected.");

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            // Prompt the client for password
            out.println("Enter password:");

            // Receive password from client
            String passwordAttempt = in.readLine();
            System.out.println("Received password: " + passwordAttempt);

            // Check password
            if (passwordAttempt.equals(PASSWORD)) {
                out.println("Authentication successful. You can now send messages.");
                System.out.println("Authentication successful.");

                // Start a separate thread to listen for client messages
                Thread clientListener = new Thread(() -> {
                    try {
                        String clientMessage;
                        while ((clientMessage = in.readLine()) != null) {
                            System.out.println("Client: " + clientMessage);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
                clientListener.start();

                // Send messages to client
                BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));
                String userInput;
                while ((userInput = consoleInput.readLine()) != null) {
                    out.println(userInput);
                }
            } else {
                out.println("Authentication failed. Connection closed.");
                clientSocket.close();
                serverSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 1234);
            System.out.println("Connected to server.");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader consoleInput = new BufferedReader(new InputStreamReader(System.in));

            // Wait for the server to prompt for password
            String authenticationStatus = in.readLine();
            System.out.println("Server: " + authenticationStatus);

            // If server asks for password, prompt the user to enter it
            if (authenticationStatus.equals("Enter password:")) {
                System.out.println("Please enter password:");
                String password = consoleInput.readLine();
                out.println(password); // Send password to server

                // Receive authentication response from server
                String response = in.readLine();
                System.out.println("Server: " + response);

                if (response.equals("Authentication successful. You can now send messages.")) {
                    System.out.println("You can now start sending messages. Type 'exit' to quit.");

                    // Start a separate thread to listen for server messages
                    Thread serverListener = new Thread(() -> {
                        try {
                            String serverMessage;
                            while ((serverMessage = in.readLine()) != null) {
                                System.out.println("Server: " + serverMessage);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
                    serverListener.start();

                    // Send messages to server
                    String userInput;
                    while ((userInput = consoleInput.readLine()) != null) {
                        out.println(userInput);
                        if (userInput.equalsIgnoreCase("exit")) {
                            break;
                        }
                    }
                } else {
                    // Close connection if authentication failed
                    socket.close();
                }
            } else {
                System.out.println("Unexpected response from server. Connection closed.");
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
